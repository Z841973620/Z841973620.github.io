#!/bin/bash

version="3.1.7"
version_token="DGX_OTA_VERSION"

release_file_path="./debs/dgxserver_3.x/post_install/dgx-release"
src="."
dest=".."
tarname="xenial.tar.gz"
gpgname="$tarname.gpg"

if [[ "$1" != "" ]]
then
    dest=$1
fi

tarpath="$dest/$tarname"
gpgpath="$dest/$gpgname"

#echo "" > $release_file_path
#echo $version_token=\"$version\" >> $release_file_path
mydate=$(date)
echo DGX_TARBALL_BUILD_DATE=\"$mydate\" > $release_file_path

sudo tar --exclude=.git --exclude=.project --exclude=.pydevproject --exclude=.settings -zcvf $tarpath $src
gpg --output $gpgpath --detach-sign $tarpath

