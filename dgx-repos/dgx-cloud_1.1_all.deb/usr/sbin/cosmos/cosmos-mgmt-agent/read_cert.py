#!/usr/bin/python
#
#  Script to read client certificate from BMC using ipmitool
#
import argparse
import os
import sys
import commands
import re

_SCRIPT_NAME = os.path.basename(__file__).replace('.py', '')

def Usage():
        print " "
        print "Usage:"
        print "  %s --size SIZE" % os.path.basename(__file__)
        print " "
        print "  Where SIZE is the size of the certificate in bytes"
        print " "

def configure_parser():
        formatter = argparse.RawDescriptionHelpFormatter
        parser    = argparse.ArgumentParser(usage                 = None,
                                            fromfile_prefix_chars = '@',
                                            formatter_class       = formatter,
                                            description           = __doc__,
                                            prog                  = _SCRIPT_NAME)
        parser.add_argument('-s', '--size',
                            help = 'The size of the certificate in bytes.')
        return parser

def readFromBMC(size):

        startAddress = 0x3000

        sliceStart = sliceEnd = 0

        readBack = ''
        firstLine = True

        # This is the hex regular expression, so we can grab just that
        hexRE = re.compile(r'([ 0-9a-f]+)')
        while ( sliceEnd != int(size) ):

            # Read back in 16 byte chunks
            sliceEnd     = min(sliceStart + 16, int(size))
            count = sliceEnd - sliceStart

            command = 'ipmitool raw 0x06 0x52 0x0d 0xa8 0x%02x 0x%02x 0x%02x ' % (count, (startAddress>>8), (startAddress&0xFF))

            output = runCommand(command)

            # The Quanta version of ipmitool prints out some header information before the hex
            # so get rid of that.  Only doing one line at a time.
            outputLine = "None"
            for line in output.split('\n'):
                if hexRE.match(line):
                    outputLine = line
                    break

            # What we get back does not have '0x', so strip off

            outstrip = outputLine.lstrip(' ')

            if firstLine:
                # Strip first space of first line
                readBack += outstrip
                firstLine = False
            else:
                readBack += outputLine

            sliceStart   = min(sliceStart + 16, int(size)+1)
            startAddress += 16

        # convert hex output back to ASCII
        readBack.replace(' ', ' 0x') 
        asciilist = []
        for i in readBack.split(' '):
            asciilist.append(chr(int(i,16)))

        asciilist = ''.join(asciilist)

        # Print out the ASCII version of what is read back
        print asciilist

def runCommand(command):
    try:
        (status, output) = commands.getstatusoutput(command)
        if status != 0:
           print output
           raise Exception(output)
        else:
           return output

    except Exception, e:
        print "ERROR: %s" % e
        sys.exit(1)

def main(args):
        parser = configure_parser()
        options = parser.parse_args(args)

        if (options.size == None):
            Usage()
            return;

        try:
                readFromBMC(options.size)

        except IOError as e:
                print "*** " + str(e)
                return 1
        except RuntimeError as e:
                print "*** " + str(e)
                return 1
        return 0


### Main entry ###
if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

