#!/usr/bin/python

import os
import subprocess
import sys
import json
from pprint import pprint
from subprocess import call

_COSMOS_DIR = "/usr/sbin/cosmos/"

## Use this API to set a value within the database
def setKey(key, value):
    p = subprocess.Popen('python '+_COSMOS_DIR+'cosmos-mgmt-agent/cosmosdb.py -k '+key+' -v '+value, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT);

def executeBashCmd(cmd):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT);
    try:
        return (p.stdout.readlines())[0];
    except:
        return "na"

def uninstallCosmos(name):
    # Need this to run with nohup, otherwise the package db gets corrupted
    p = subprocess.Popen(['nohup', 'apt-get', 'purge', '-y' , name],
         stdout=open('/dev/null', 'w'),
         stderr=open('/var/log/logfile.log', 'a'),
         preexec_fn=os.setpgrp)
    return p.wait();

def blockingCmd(cmd):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT);
    return p.wait();

def main():

    setKey("repo_url", "na");
    setKey("cloud_url", "na");

    # Make sure that the cosmos-stack package is present before you proceed forward
    if (executeBashCmd("dpkg -s cosmos-stack | grep Status | awk '{print $1;}'").strip()== "Status:"):
        executeBashCmd(_COSMOS_DIR+"cosmos-stack/cleanup_cosmos.py");

    executeBashCmd("echo \" \" > /etc/apt/sources.list.d/dgx1-bootstrap.list");
    executeBashCmd("mv -f /etc/apt/sources.list.ubuntu /etc/apt/sources.list");

    uninstallCosmos("dgx1-bootstrap");
    uninstallCosmos("dgx1-bootstrap-repo-ubuntu1404");
    executeBashCmd("[[ -f /etc/apt/sources.list.d/dgx1-bootstrap.list ]] && >/etc/apt/sources.list.d/dgx1-bootstrap.list");

    # Undo the changes we have done in the postinst of dgx1-bootstrap package
    # TODO: Move these into another undo script that you add to dgx1-bootstrap
    executeBashCmd("sed -i \"s/#send host-name = gethostname()/send-host-name = gethostname()/g\" /etc/dhcp/dhclient.conf");
    executeBashCmd("sed -i \"s/send dhcp-client-identifier/#send dhcp-client-identifier 1:0:a0:24:ab:fb:9c;/g\" /etc/dhcp/dhclient.conf");

    # Need this to run with nohup, otherwise the package db gets corrupted
    uninstallCosmos("dgx-cloud");
    blockingCmd("apt-get -y autoremove")

### Main entry ###
if __name__ == "__main__":
    sys.exit(main())
