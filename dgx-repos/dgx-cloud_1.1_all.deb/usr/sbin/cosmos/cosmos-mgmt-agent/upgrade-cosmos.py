#!/usr/bin/python

import os
import subprocess
import sys
import json
from pprint import pprint
from subprocess import call
import os.path
import fcntl
import errno
import time
import datetime
import socket
import fcntl
import struct

_COSMOS_DIR = "/usr/sbin/cosmos/";
_LOCKFILE = '/srv/cosmos-mgmt-agent/upgradeLock';
_UPGRADE_BOOT_FILE = "/tmp/upgrade-dgx1-bootstrap";
_XEN_UPGRADE_BOOT_FILE = "/var/log/cosmos/upgrade-dgx1-bootstrap";
_COSMOS_LOG_FILE = "/var/log/cosmos/cosmos-upgrade.log"
_APT_GET_LOG_FILE = "/tmp/apt-get-upgrade.log"
_SSL_CLIENT_KEY = "/etc/ssl/private/client.key"
_SSL_CLIENT_CRT = "/etc/ssl/private/client.crt"

log = ""

def get_ip_address(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

def addLog(text):
    global log;
    ts = time.time()
    st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
    log.write(st+": "+text+"\n");
    log.flush();

## Use this API to set a value within the database
def setKey(key, value):
    p = subprocess.Popen('python '+_COSMOS_DIR+'cosmos-mgmt-agent/cosmosdb.py -k '+key+' -v '+value, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT);

def execute_cmd(cmd):
    addLog("Executing command : " + str(cmd))
    process = subprocess.Popen(cmd, stdout = subprocess.PIPE, stderr = subprocess.PIPE, shell=True)
    process_output, process_error = process.communicate()
    return process_output, process.returncode

def blockingCmdWithLog(cmd, name):
    log = open(name, "a")
    p = subprocess.Popen(cmd, shell=True, universal_newlines=True, stdout=log, stderr=log);
    ret_code = p.wait()
    log.flush()
    log.close();
    return ret_code

def blockingCmd(cmd):
    try:
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT);
        return p.wait();
    except:
        return 1

def executeBashCmd(cmd):
    try:
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT);
        return (p.stdout.readlines())[0];
    except:
        return "na"

## Use this API to query the database
def queryDB(key):
    try:
        p = subprocess.Popen('python '+_COSMOS_DIR+'cosmos-mgmt-agent/cosmosdb.py -j -k '+key, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT);
        jstr = (p.stdout.readlines())[0];
        jstr = jstr.strip();
        jsonstr=json.loads(jstr);
        return jsonstr[key]
    except:
        return "na"

def manageFirstBoot():
    if (queryDB("first_boot") != "yes"):
        return;

    setKey("first_boot", "no");

def main():
    global log;
    manageFirstBoot();
    log = open(_COSMOS_LOG_FILE, "a")

    ip = queryDB("ip_address");
    serial_number = queryDB("serial_number");
    setKey("gpu_configuration", executeBashCmd("lspci -d 10de:* | wc -l").strip());
    setKey("cpu_sockets", executeBashCmd("lscpu | grep Socket | wc -l").strip());
    setKey("total_cpu_cores", executeBashCmd("nproc").strip());
    setKey("cpu_model_name", executeBashCmd("cat /proc/cpuinfo | grep \"model name\" | uniq | cut -d \" \" -f 3-").strip());
    setKey("cpu_cores_per_socket", executeBashCmd("lscpu | grep \"Core(s) per socket\"|cut -d \" \" -f 4-").strip());
    # this is a bug... need nvidia-smi to be installed to get the GPU model name
    setKey("gpu_model_name", executeBashCmd("na").strip());
    rebootDate = executeBashCmd("/usr/bin/who -b|awk '{print $3}'").strip();
    rebootTime = executeBashCmd("/usr/bin/who -b|awk '{print $4}'").strip();

    timeOfReboot = rebootDate + " " + rebootTime;
    setKey("time_of_reboot", timeOfReboot);

    isVM = False
    out,ret = execute_cmd("lsmod | grep xen");
    if len(out) != 0:
        isVM = True
    
    if (not isVM):
        # try this sequence twice just in case the network interfaces take
        # a bit to come up
        for x in range (0,1):
            eth1 = executeBashCmd("cat /sys/class/net/em1/operstate").strip();
            eth2 = executeBashCmd("cat /sys/class/net/em2/operstate").strip();

            if (eth2 == "na"):
                eth2 = "down";
            
            if ( eth1 == "up" or eth2 == "up" ):
                break;
            if ( eth1 != "up" and eth2 != "up" and x != 0):
                return;
            time.sleep(10)

        cmd = executeBashCmd("/sbin/route | grep default | sed -e \"s/  */ /g\" | cut -f 8 -d \" \"").strip();
        ip = executeBashCmd("sbin/ifconfig "+ cmd +"| grep inet | cut -f 2 -d \":\" | cut -f 1 -d \" \"").strip();
        if (ip != queryDB("ip_address")):
            setKey("ip_address", ip);

        sr_num = executeBashCmd("dmidecode -t system | grep Serial | awk -F: '{print $2}'").strip();
        if (serial_number != sr_num):
            setKey("serial_number", sr_num);
            setKey("node_name", sr_num);

        biosVersion = executeBashCmd("/usr/bin/ipmitool -U qct.admin -P qct.admin raw 0x30 0x83").strip();
        bmcVersion = executeBashCmd("/usr/bin/ipmitool mc info|grep 'Firmware Revision' | awk '{print $4}'").strip();
        gateway   = executeBashCmd("/sbin/route | grep default | awk '{print $2}'").strip();
        setKey("gateway", biosVersion);
        setKey("bios_version", biosVersion);
        setKey("bmc_version", bmcVersion);
        mem_size = executeBashCmd("dmidecode -t 17| grep \"Size.*MB\" | awk '{s+=$2} END {print s}'");
        setKey("memory", mem_size);
    else:
        sr_num = None
        cloud_url = None
        try:
            import json;
            userdata_file = "/var/lib/cloud/instance/user-data.txt";
            f = open(userdata_file);
            userdata_json = json.loads(f.read());
            sr_num = userdata_json["serial_number"];
            cloud_url = userdata_json["cloud_url"];
        except:
            addLog("Error reading cloudinit instance userdata");

        setKey("ip_address", get_ip_address('eth0'));
        if (serial_number != sr_num):
            setKey("serial_number", str(sr_num));
            setKey("node_name", str(sr_num));
        setKey("cloud_url", str(cloud_url));

    # Don't upgrade if we have already upgraded during this boot
    if (os.path.isfile(_UPGRADE_BOOT_FILE)):
        return;

    setKey("is_master", "no");

    # Don't upgrade if we if this simulator and if the following file is present in the Xen env
    # Note: The Xen env places this file at the appropriate location.
    if (os.path.isfile(_XEN_UPGRADE_BOOT_FILE)):
        return;

    processUpgrade();
    log.close();

def processUpgrade():

    # Stop cosmos-collectd just incase and start it after the upgrade
    addLog("Stopping cosmos services");
    executeBashCmd(_COSMOS_DIR+"cosmos-stack/stop_all_services.py");

    # Change the repo URL if need be
    serial_number = queryDB("serial_number");
    cloud_url = queryDB("cloud_url");
    if (cloud_url == "na"):
        if (serial_number[:5] == "STG1_"):
            executeBashCmd("echo \"deb http://dgx1-bootstrap-repo-staging1.nvidia.com/ trusty main multiverse restricted universe\" > /etc/apt/sources.list.d/dgx1-bootstrap.list");
        elif (serial_number[:5] == "DEV1_"):
            executeBashCmd("echo \"deb http://dgx1-bootstrap-repo-devel1.nvidia.com/ trusty main multiverse restricted universe\" > /etc/apt/sources.list.d/dgx1-bootstrap.list");
        elif (serial_number[:4] == "QA1_"):
            executeBashCmd("echo \"deb http://dgx1-bootstrap-repo-qa1.nvidia.com/ trusty main multiverse restricted universe\" > /etc/apt/sources.list.d/dgx1-bootstrap.list");
        else:
            executeBashCmd("echo \"deb https://dgx1-bootstrap-repo.nvidia.com/ trusty main multiverse restricted universe\" > /etc/apt/sources.list.d/dgx1-bootstrap.list");

    certs = subprocess.Popen(["/usr/sbin/cosmos/cosmos-mgmt-agent/read_cert.py -s 996"], shell=True, stdout=subprocess.PIPE).stdout.read();
    certsplit = certs.splitlines(certs.count('\n'))

    priv = False
    pubkey = ""
    privkey = ""

    for line in certsplit:
        if line.startswith('-----BEGIN EC PRIVATE'):
            priv = True
        if priv is False:
            pubkey = pubkey + line
        else:
            privkey = privkey + line

    if (priv == True): #only write the keys if we found some
        with open(_SSL_CLIENT_KEY, "w") as text_file:
            text_file.write(privkey)
        text_file.close()

        with open(_SSL_CLIENT_CRT, "w") as text_file:
            text_file.write(pubkey)
        text_file.close()

        executeBashCmd("chmod 600 " + _SSL_CLIENT_KEY)
        executeBashCmd("chmod 600 " + _SSL_CLIENT_CRT)

    # Ping the repo... return if ping fails
    if (blockingCmd("ping -c 1 www.nvidia.com") != 0):
        addLog("Unable to ping www.nvidia.com! Network seems to be down...");
        return;

    # Add the marker file
    addLog("Creating touch file...");
    executeBashCmd("touch "+_UPGRADE_BOOT_FILE);
    setKey("update_in_progress", "true");

    # Upgrade happens only if this flag is 'yes'; otherwise, its bypassed
    upgrade_on_boot = queryDB("upgrade_on_boot");
    ret_val = 1
    if (upgrade_on_boot == "yes"):
        addLog("Initiating apt-get...");

        # Start the apt-get process
        try:
            ret_val = blockingCmdWithLog("apt-get update", _APT_GET_LOG_FILE);
            ret_val = blockingCmdWithLog("apt-get -y --no-install-recommends upgrade", _APT_GET_LOG_FILE);
            ret_val = blockingCmdWithLog("apt-get -y --no-install-recommends install cuda-drivers", _APT_GET_LOG_FILE);

            # Do one more update
            ret_val = blockingCmdWithLog("apt-get update", _APT_GET_LOG_FILE);
            ret_val = blockingCmdWithLog("apt-get -y --no-install-recommends install dgx1-bootstrap", _APT_GET_LOG_FILE);
            ret_val = blockingCmdWithLog("apt-get -y autoremove", _APT_GET_LOG_FILE);

            addLog("apt-get complete!");
        except:
            addLog("apt-get failed");

        if (ret_val == 0):
            addLog("Upgrade successful");
            setKey("update_in_progress", "false");
        else:
            addLog("Upgrade failed");
            setKey("update_in_progress", "failed");

    # Adding the repo_url to the database
    repo_url = executeBashCmd("cat /etc/apt/sources.list.d/dgx1-bootstrap.list|cut -d' ' -f2").strip();
    setKey("repo_url", repo_url);

    # Now, update the database with the latest version of dgx1-bootstrap
    ver=executeBashCmd("dpkg-query --showformat='${Version}' --show dgx1-bootstrap").strip();
    setKey("sw_version", ver);
    addLog("Latest Sofware Version: "+ver);
    addLog("Starting cosmos services");

    # Restart collectd service
    executeBashCmd(_COSMOS_DIR+"cosmos-stack/start_slave_services.py");

    ##############################################################
    ### The following commands need to execute one upon reboot ###
    # Control comes here only once after reboot
    executeBashCmd("/usr/bin/nvidia-smi -pm 1");
    executeBashCmd("/sbin/modprobe nv_peer_mem");

### Main entry ###
if __name__ == "__main__":
    sys.exit(main())
