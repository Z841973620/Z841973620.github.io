import{_ as o,c as r,a as n,o as t,r as c}from"./index.cba6999c.js";const a={};function s(_,i){const e=c("router-view");return t(),r("div",null,[n(e)])}var d=o(a,[["render",s]]);export{d as default};
