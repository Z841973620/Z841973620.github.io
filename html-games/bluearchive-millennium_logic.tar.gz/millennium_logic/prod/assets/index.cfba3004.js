import{_ as o,r,o as n,c as t,a as c}from"./index.e7d97191.js";const a={};function s(_,i){const e=r("router-view");return n(),t("div",null,[c(e)])}var d=o(a,[["render",s]]);export{d as default};
