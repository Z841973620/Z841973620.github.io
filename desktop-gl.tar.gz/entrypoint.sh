#!/bin/bash
/opt/websockify/run 5901 --web=/opt/noVNC --wrap-mode=ignore -- vncserver :1 -3dwm &
sleep 1
startxfce4